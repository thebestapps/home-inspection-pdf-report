(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"],
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\"> </ion-buttons>\n    <ion-title> Home Inspection</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item>\n      <ion-row style=\"text-align: center\">\n        <ion-col style=\"text-align: center\">\n          <ion-button\n            class=\"cus-top-selection-btn createins\"\n            (click)=\"CreateInspectionForm()\"\n          >\n            <span class=\"ot\">\n              <ion-icon class=\"add-circle-ic\" name=\"create-outline\"></ion-icon>\n            </span>\n            Create Inspection\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-item>\n\n    <!-- <ion-item>\n      <ion-row>\n        <ion-col>\n          <div class=\"cus-top-selection-btn createins\" (click)=\"SavedPDFSHow()\">\n            <ion-icon class=\"add-circle-ic\" name=\"save-outline\"></ion-icon>\n\n            <p class=\"menu-txt\">Saved PDF</p>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-item> -->\n  </ion-list>\n\n  <div class=\"content-box\">\n    <div class=\"slide-box\" *ngFor=\"let m of allDocsCreated\">\n      <ion-row *ngFor=\"let c of m.client_Info\">\n        <ion-col size=\"6\" size-sm=\"6\">\n          <div class=\"content-one\">\n            <p class=\"subtitle-content\">Client Name</p>\n            <p class=\"text-info\">{{c.clientName}}</p>\n            <p class=\"subtitle-content\">Address</p>\n            <p class=\"text-info\">\n              <ion-icon\n                class=\"add-icn\"\n                name=\"navigate-circle-outline\"\n              ></ion-icon>\n              {{c.inspectionAddress}}\n            </p>\n            <p class=\"subtitle-content\">Inspector</p>\n            <p class=\"text-info\">{{c.inspector}}</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\" size-sm=\"6\">\n          <div class=\"content-two\">\n            <p class=\"subtitle-content\">Report Number</p>\n            <p class=\"text-info\">{{c.reportNumber}}</p>\n\n            <p class=\"subtitle-content\">Inspection Date</p>\n            <p class=\"text-info\">\n              {{c.inspectionDate | date: 'dd/MM/yyyy H:mm'}}\n            </p>\n          </div>\n\n          <div class=\"on-mid\">\n            <p class=\"title-btn\">\n              <button class=\"edit-btn\" (click)=\"openCommonModal(m)\">\n                Edit\n              </button>\n            </p>\n          </div>\n        </ion-col>\n        <!-- <ion-col size=\"12\" size-sm=\"6\" size-md=\"4\">\n          <div class=\"content-three\">\n            <div class=\"content-right\">\n          \n            </div>\n          </div>\n        </ion-col> -->\n      </ion-row>\n    </div>\n  </div>\n\n  <!-- <div class=\"container-home\">\n    <ion-row class=\"row-cls\" *ngFor=\"let m of allDocsCreated\">\n  \n\n      <div class=\"card-cus\" *ngFor=\"let c of m.client_Info\">\n        <ion-row>\n          <ion-col>\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Client Name</p>\n              <p class=\"hz-txt\">{{c.clientName}}</p>\n            </div>\n\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">inspectionAddress</p>\n              <p class=\"hz-txt\">{{c.inspectionAddress}}</p>\n            </div>\n          </ion-col>\n\n          <ion-col>\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Inspector</p>\n              <p class=\"hz-txt\">{{c.inspector}}</p>\n            </div>\n\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Report Number</p>\n              <p class=\"hz-txt\">{{c.reportNumber}}</p>\n            </div>\n          </ion-col>\n        </ion-row>\n\n        <div class=\"date-only\">\n          <p class=\"lb-txt\">Inspection Date</p>\n          <p class=\"date-field\">{{c.inspectionDate}}</p>\n        </div>\n      </div>\n\n      <button class=\"edit-button2\" (click)=\"openCommonModal(m)\">\n        <ion-icon class=\"edit-icn2\" name=\"create-outline\"></ion-icon>\n      </button>\n    </ion-row>\n  </div> -->\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-cus {\n  margin-left: 20px;\n  margin-right: 20px;\n}\n\np.lb-txt {\n  font-size: 12px;\n}\n\np.hz-txt {\n  margin-top: -9px;\n}\n\np.date-field {\n  margin-top: -9px;\n}\n\nion-icon.icn-top.ios.hydrated {\n  margin-right: 7px;\n}\n\nion-icon.icn-top.md.hydrated {\n  margin-right: 7px;\n}\n\nion-button.cus-top-selection-btn.createins.ios.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --border-radius: 11px;\n  text-transform: capitalize;\n}\n\nion-button.cus-top-selection-btn.createins.md.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --border-radius: 11px;\n  text-transform: capitalize;\n}\n\nspan.ot {\n  border-right: 1px solid;\n  margin-right: 6px;\n}\n\nbutton.edit-btn {\n  float: right;\n  margin-top: 9px;\n  margin-right: 17px;\n  display: flex;\n  border-radius: 17px;\n  font-size: 16px;\n  padding-left: 5px;\n  padding-top: 3px;\n  padding-bottom: 3px;\n  padding-right: 7px;\n  color: #222428;\n}\n\nion-icon.edit-icn.md.hydrated {\n  color: #222428;\n  font-size: 18px;\n  margin-top: -2px;\n}\n\nion-icon.edit-icn.ios.hydrated {\n  color: #222428;\n  font-size: 18px;\n  margin-top: -2px;\n}\n\nion-row.row-cls.md.hydrated {\n  background: white;\n  padding-left: 12px;\n  width: 100%;\n  margin-top: 20px;\n  border-radius: 10px;\n  box-shadow: 10px 10px 5px 0px #d7d8da;\n  -webkit-box-shadow: 10px 10px 5px 0px #989aa2;\n  -moz-box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n  color: black;\n  margin-left: 14px;\n}\n\n.cus-top-selection-btn.createins {\n  display: inline-flex;\n}\n\nion-row.row-cls.ios.hydrated {\n  background: white;\n  padding-left: 12px;\n  width: 100%;\n  margin-top: 20px;\n  border-radius: 10px;\n  box-shadow: 10px 10px 5px 0px #d7d8da;\n  -webkit-box-shadow: 10px 10px 5px 0px #989aa2;\n  -moz-box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n  color: black;\n  margin-left: 14px;\n}\n\nion-icon.add-circle-ic.md.hydrated {\n  margin-top: 2px;\n  margin-right: 4px;\n  font-size: 16px;\n}\n\nion-content.md.hydrated {\n  --background: #f2f2f2;\n}\n\nion-content.ios.hydrated {\n  --background: #f2f2f2;\n}\n\nion-icon.add-circle-ic.ios.hydrated {\n  margin-top: 2px;\n  margin-right: 4px;\n  font-size: 16px;\n}\n\n.date-only {\n  margin-top: -25px;\n}\n\n.content-box {\n  background-repeat: no-repeat, repeat;\n  background-position: right top;\n  background-image: url('background-rect.png');\n  background-attachment: fixed;\n}\n\n.slide-box {\n  margin-left: 10px;\n  margin-right: 10px;\n  margin-top: 19px;\n  margin-bottom: 25px;\n  background: white;\n  border-radius: 30px;\n}\n\n@media only screen and (min-width: 900px) {\n  .slide-box {\n    width: 75% !important;\n  }\n\n  .slide-box.singleorder {\n    width: 93% !important;\n    margin-left: 27px;\n  }\n\n  button.edit-btn {\n    position: fixed;\n    top: 10;\n    top: 110px !important;\n    right: 0px;\n    margin-right: 31px;\n  }\n}\n\nbutton.edit-btn {\n  position: revert;\n  top: 10;\n  top: auto;\n  right: auto;\n  margin-right: auto;\n}\n\n.content-one {\n  padding-left: 22px;\n}\n\np.c-title {\n  color: #193f6a;\n  background: #f5f5f5;\n  text-align: center;\n  height: 27px;\n  padding-top: 4px;\n  font-size: 16px;\n  border-radius: 60px;\n  margin-top: 12px;\n  margin-bottom: 25px;\n  padding-left: 10px;\n  padding-right: 10px;\n  width: 126px;\n  overflow: hidden;\n  height: 24px;\n  padding-bottom: 19px;\n}\n\np.subtitle-content {\n  font-size: 11px;\n  margin-bottom: -19px;\n  font-family: \"Poppins\";\n  color: #193f6aab;\n  font-family: \"Poppins\";\n}\n\np.text-info {\n  line-height: 18px;\n}\n\np.text-info {\n  color: #193f6a;\n  font-family: \"Poppins\";\n  font-size: 15px;\n  margin-bottom: 17px;\n  margin-top: 18px;\n}\n\n.content-two {\n  margin-top: 62px;\n}\n\n.slide-box {\n  background-repeat: no-repeat, repeat;\n  background-position: bottom center;\n  background-image: url('group-circles.png') !important;\n}\n\n.on-mid {\n  margin-top: 0px !important;\n  padding-left: 22px !important;\n}\n\n.content-two {\n  margin-top: 0px !important;\n  padding-left: 22px !important;\n}\n\n.content-three {\n  padding-left: 4px !important;\n  padding-bottom: 13px;\n}\n\np.title-btn {\n  float: right;\n}\n\nion-button.cus-top-selection-btn.createins.md.button.button-small.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n}\n\nion-button.cus-top-selection-btn.createins.ios.button.button-small.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQVdBO0VBQ0UsZUFBQTtBQVJGOztBQVdBO0VBQ0UsZ0JBQUE7QUFSRjs7QUFXQTtFQUNFLGdCQUFBO0FBUkY7O0FBV0E7RUFDRSxpQkFBQTtBQVJGOztBQVdBO0VBQ0UsaUJBQUE7QUFSRjs7QUFXQTtFQUNFLHFCQUFBO0VBQ0EsMEJBQUE7QUFSRjs7QUFXQTtFQUNFLHFCQUFBO0VBQ0EsMEJBQUE7QUFSRjs7QUFXQTtFQUNFLHVCQUFBO0VBRUEsaUJBQUE7QUFURjs7QUFZQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBVEY7O0FBWUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBVEY7O0FBWUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtFQUNBLDZDQUFBO0VBQ0Esc0RBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFURjs7QUFZQTtFQUNFLG9CQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtFQUNBLDZDQUFBO0VBQ0Esc0RBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFURjs7QUFZQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFURjs7QUFZQTtFQUNFLHFCQUFBO0FBVEY7O0FBWUE7RUFDRSxxQkFBQTtBQVRGOztBQVlBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQVRGOztBQVlBO0VBQ0UsaUJBQUE7QUFURjs7QUFZQTtFQUNFLG9DQUFBO0VBQ0EsOEJBQUE7RUFDQSw0Q0FBQTtFQUNBLDRCQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFURjs7QUFZQTtFQUNFO0lBQ0UscUJBQUE7RUFURjs7RUFXQTtJQUNFLHFCQUFBO0lBQ0EsaUJBQUE7RUFSRjs7RUFVQTtJQUNFLGVBQUE7SUFDQSxPQUFBO0lBQ0EscUJBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUFQRjtBQUNGOztBQVVBO0VBQ0UsZ0JBQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQVJGOztBQVdBO0VBQ0Usa0JBQUE7QUFSRjs7QUFXQTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBRUEsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUFURjs7QUFZQTtFQUNFLGVBQUE7RUFDQSxvQkFBQTtFQUVBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQVZGOztBQWFBO0VBQ0UsaUJBQUE7QUFWRjs7QUFhQTtFQUNFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBVkY7O0FBYUE7RUFDRSxnQkFBQTtBQVZGOztBQWNBO0VBQ0Usb0NBQUE7RUFDQSxrQ0FBQTtFQUNBLHFEQUFBO0FBWEY7O0FBY0E7RUFDRSwwQkFBQTtFQUNBLDZCQUFBO0FBWEY7O0FBY0E7RUFDRSwwQkFBQTtFQUNBLDZCQUFBO0FBWEY7O0FBY0E7RUFDRSw0QkFBQTtFQUNBLG9CQUFBO0FBWEY7O0FBZUE7RUFDRSxZQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtFQUNBLCtCQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtFQUNBLCtCQUFBO0FBWkYiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZC1jdXMge1xuICBtYXJnaW4tbGVmdDogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIC8vIHBhZGRpbmctbGVmdDogMTJweDtcbiAgLy8gd2lkdGg6IDEwMCU7XG4gIC8vIG1hcmdpbi10b3A6IDIwcHg7XG4gIC8vIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIC8vIGJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4ICNkN2Q4ZGE7XG4gIC8vIC13ZWJraXQtYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggIzk4OWFhMjtcbiAgLy8gLW1vei1ib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCByZ2JhKDAsIDAsIDAsIDAuNzUpO1xuICAvLyBjb2xvcjogI2ZmZmZmZmFiO1xufVxuXG5wLmxiLXR4dCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxucC5oei10eHQge1xuICBtYXJnaW4tdG9wOiAtOXB4O1xufVxuXG5wLmRhdGUtZmllbGQge1xuICBtYXJnaW4tdG9wOiAtOXB4O1xufVxuXG5pb24taWNvbi5pY24tdG9wLmlvcy5oeWRyYXRlZCB7XG4gIG1hcmdpbi1yaWdodDogN3B4O1xufVxuXG5pb24taWNvbi5pY24tdG9wLm1kLmh5ZHJhdGVkIHtcbiAgbWFyZ2luLXJpZ2h0OiA3cHg7XG59XG5cbmlvbi1idXR0b24uY3VzLXRvcC1zZWxlY3Rpb24tYnRuLmNyZWF0ZWlucy5pb3MuYnV0dG9uLmJ1dHRvbi1zb2xpZC5pb24tYWN0aXZhdGFibGUuaW9uLWZvY3VzYWJsZS5oeWRyYXRlZCB7XG4gIC0tYm9yZGVyLXJhZGl1czogMTFweDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59XG5cbmlvbi1idXR0b24uY3VzLXRvcC1zZWxlY3Rpb24tYnRuLmNyZWF0ZWlucy5tZC5idXR0b24uYnV0dG9uLXNvbGlkLmlvbi1hY3RpdmF0YWJsZS5pb24tZm9jdXNhYmxlLmh5ZHJhdGVkIHtcbiAgLS1ib3JkZXItcmFkaXVzOiAxMXB4O1xuICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbn1cblxuc3Bhbi5vdCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkO1xuXG4gIG1hcmdpbi1yaWdodDogNnB4O1xufVxuXG5idXR0b24uZWRpdC1idG4ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDlweDtcbiAgbWFyZ2luLXJpZ2h0OiAxN3B4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBib3JkZXItcmFkaXVzOiAxN3B4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIHBhZGRpbmctbGVmdDogNXB4O1xuICBwYWRkaW5nLXRvcDogM3B4O1xuICBwYWRkaW5nLWJvdHRvbTogM3B4O1xuICBwYWRkaW5nLXJpZ2h0OiA3cHg7XG4gIGNvbG9yOiAjMjIyNDI4O1xufVxuXG5pb24taWNvbi5lZGl0LWljbi5tZC5oeWRyYXRlZCB7XG4gIGNvbG9yOiAjMjIyNDI4O1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IC0ycHg7XG59XG5cbmlvbi1pY29uLmVkaXQtaWNuLmlvcy5oeWRyYXRlZCB7XG4gIGNvbG9yOiAjMjIyNDI4O1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IC0ycHg7XG59XG5cbmlvbi1yb3cucm93LWNscy5tZC5oeWRyYXRlZCB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBwYWRkaW5nLWxlZnQ6IDEycHg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCAjZDdkOGRhO1xuICAtd2Via2l0LWJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4ICM5ODlhYTI7XG4gIC1tb3otYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogMTRweDtcbn1cblxuLmN1cy10b3Atc2VsZWN0aW9uLWJ0bi5jcmVhdGVpbnMge1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbn1cblxuaW9uLXJvdy5yb3ctY2xzLmlvcy5oeWRyYXRlZCB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBwYWRkaW5nLWxlZnQ6IDEycHg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCAjZDdkOGRhO1xuICAtd2Via2l0LWJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4ICM5ODlhYTI7XG4gIC1tb3otYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogMTRweDtcbn1cblxuaW9uLWljb24uYWRkLWNpcmNsZS1pYy5tZC5oeWRyYXRlZCB7XG4gIG1hcmdpbi10b3A6IDJweDtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuaW9uLWNvbnRlbnQubWQuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG59XG5cbmlvbi1jb250ZW50Lmlvcy5oeWRyYXRlZCB7XG4gIC0tYmFja2dyb3VuZDogI2YyZjJmMjtcbn1cblxuaW9uLWljb24uYWRkLWNpcmNsZS1pYy5pb3MuaHlkcmF0ZWQge1xuICBtYXJnaW4tdG9wOiAycHg7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5kYXRlLW9ubHkge1xuICBtYXJnaW4tdG9wOiAtMjVweDtcbn1cblxuLmNvbnRlbnQtYm94IHtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdCwgcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiByaWdodCB0b3A7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi9hc3NldHMvUmVzL2JhY2tncm91bmQtcmVjdC5wbmcpO1xuICBiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6IGZpeGVkO1xufVxuXG4uc2xpZGUtYm94IHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgbWFyZ2luLXRvcDogMTlweDtcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogOTAwcHgpIHtcbiAgLnNsaWRlLWJveCB7XG4gICAgd2lkdGg6IDc1JSAhaW1wb3J0YW50O1xuICB9XG4gIC5zbGlkZS1ib3guc2luZ2xlb3JkZXIge1xuICAgIHdpZHRoOiA5MyUgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tbGVmdDogMjdweDtcbiAgfVxuICBidXR0b24uZWRpdC1idG4ge1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB0b3A6IDEwO1xuICAgIHRvcDogMTEwcHggIWltcG9ydGFudDtcbiAgICByaWdodDogMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMzFweDtcbiAgfVxufVxuXG5idXR0b24uZWRpdC1idG4ge1xuICBwb3NpdGlvbjogcmV2ZXJ0O1xuICB0b3A6IDEwO1xuICB0b3A6IGF1dG87XG4gIHJpZ2h0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG5cbi5jb250ZW50LW9uZSB7XG4gIHBhZGRpbmctbGVmdDogMjJweDtcbn1cblxucC5jLXRpdGxlIHtcbiAgY29sb3I6ICMxOTNmNmE7XG4gIGJhY2tncm91bmQ6ICNmNWY1ZjU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgaGVpZ2h0OiAyN3B4O1xuICBwYWRkaW5nLXRvcDogNHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDYwcHg7XG5cbiAgbWFyZ2luLXRvcDogMTJweDtcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICB3aWR0aDogMTI2cHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGhlaWdodDogMjRweDtcbiAgcGFkZGluZy1ib3R0b206IDE5cHg7XG59XG5cbnAuc3VidGl0bGUtY29udGVudCB7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgbWFyZ2luLWJvdHRvbTogLTE5cHg7XG5cbiAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiO1xuICBjb2xvcjogIzE5M2Y2YWFiO1xuICBmb250LWZhbWlseTogXCJQb3BwaW5zXCI7XG59XG5cbnAudGV4dC1pbmZvIHtcbiAgbGluZS1oZWlnaHQ6IDE4cHg7XG59XG5cbnAudGV4dC1pbmZvIHtcbiAgY29sb3I6ICMxOTNmNmE7XG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAxN3B4O1xuICBtYXJnaW4tdG9wOiAxOHB4O1xufVxuXG4uY29udGVudC10d28ge1xuICBtYXJnaW4tdG9wOiA2MnB4O1xufVxuXG4vLyBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcyMHB4KSB7XG4uc2xpZGUtYm94IHtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdCwgcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBib3R0b20gY2VudGVyO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL1Jlcy9ncm91cC1jaXJjbGVzLnBuZykgIWltcG9ydGFudDtcbn1cblxuLm9uLW1pZCB7XG4gIG1hcmdpbi10b3A6IDBweCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDIycHggIWltcG9ydGFudDtcbn1cblxuLmNvbnRlbnQtdHdvIHtcbiAgbWFyZ2luLXRvcDogMHB4ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctbGVmdDogMjJweCAhaW1wb3J0YW50O1xufVxuXG4uY29udGVudC10aHJlZSB7XG4gIHBhZGRpbmctbGVmdDogNHB4ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctYm90dG9tOiAxM3B4O1xufVxuLy8gfVxuXG5wLnRpdGxlLWJ0biB7XG4gIGZsb2F0OiByaWdodDtcbn1cblxuaW9uLWJ1dHRvbi5jdXMtdG9wLXNlbGVjdGlvbi1idG4uY3JlYXRlaW5zLm1kLmJ1dHRvbi5idXR0b24tc21hbGwuYnV0dG9uLXNvbGlkLmlvbi1hY3RpdmF0YWJsZS5pb24tZm9jdXNhYmxlLmh5ZHJhdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tYnV0dG9uLmN1cy10b3Atc2VsZWN0aW9uLWJ0bi5jcmVhdGVpbnMuaW9zLmJ1dHRvbi5idXR0b24tc21hbGwuYnV0dG9uLXNvbGlkLmlvbi1hY3RpdmF0YWJsZS5pb24tZm9jdXNhYmxlLmh5ZHJhdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuIl19 */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _common_function__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common.function */ "EU1L");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../api.service */ "yTNM");
/* harmony import */ var _app_modal_create_inspection_create_inspection_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../app/modal/create-inspection/create-inspection.page */ "0ucC");
/* harmony import */ var _app_modal_common_selection_common_selection_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../app/modal/common-selection/common-selection.page */ "xVOy");










let HomePage = class HomePage {
    constructor(alertController, loadingController, config, api, modalController, platform) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.config = config;
        this.api = api;
        this.modalController = modalController;
        this.platform = platform;
        this.SavedPDFshow = false;
        this._userlogged_in = false;
        this.allDocsCreated = [];
        // this.config.storageSave('InspectionsCreated', this.allDocsCreated);
        // let newVr = [];
        // newVr.push(this.allDocsCreated);
        // newVr.push(InspectionsCreated);
        // console.log('New Vr=====' + JSON.stringify(newVr));
    }
    ionViewDidEnter() {
        let commArr = [];
        // this.config.storageRemoveItem('InspectionToEdit');
        // let vr = this.config.storageSave('InspectionToEdit', commArr);
        let InspectionsCreated = JSON.parse(this.config.storageGet('InspectionsCreated')['__zone_symbol__value']);
        // this.config.storageRemoveItem('InspectionsCreated');
        commArr = InspectionsCreated;
        console.log(JSON.stringify(commArr));
        if (InspectionsCreated == null) {
            console.log('NULL');
            this.allDocsCreated = this.config.AllDumyDocs;
        }
        else {
            console.log('NotNull');
            let InspectionsCreated = JSON.parse(this.config.storageGet('InspectionsCreated')['__zone_symbol__value']);
            // this.allDocsCreated = this.config.AllDumyDocs;
            // this.allDocsCreated = InspectionsCreated;
            this.allDocsCreated = commArr;
        }
    }
    CreateInspectionForm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.config.storageRemoveItem('InspectionToEdit');
            const modal = yield this.modalController.create({
                cssClass: 'update-popup-modal',
                component: _app_modal_create_inspection_create_inspection_page__WEBPACK_IMPORTED_MODULE_7__["CreateInspectionPage"],
                componentProps: {},
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    let d = dataReturned.data;
                    if (d.empty == 0) {
                        return;
                    }
                    if (d.empty == 1) {
                        this._userlogged_in = true;
                        let inps = JSON.parse(this.config.storageGet('CreateInspection')['__zone_symbol__value']);
                        console.log(inps);
                        this.InspectionDetail = inps.name;
                        return;
                    }
                    if (d.location) {
                    }
                }
            });
            return yield modal.present();
        });
    }
    SavedPDFSHow() {
        this.SavedPDFshow = !this.SavedPDFshow;
    }
    doRefresh() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log('Begin async operation');
            setTimeout(() => {
                console.log('Async operation has ended');
                this.api.Get_data('getalldata/dev1@gmail.com/123').subscribe((res) => {
                    // Loading_.dismiss();
                    // console.log(JSON.stringify(res));
                    this.config.commonContent = res;
                    this.config._mergeAPIContentData();
                }, (err) => {
                    // Loading_.dismiss();
                    console.log(JSON.stringify(err));
                });
                // event.target.complete();
            }, 4000);
        });
    }
    openCommonModal(c) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.doRefresh();
            this.config.storageRemoveItem('InspectionsCreated');
            // this.config.storageRemoveItem('InspectionToEdit');
            const storageData = JSON.parse(localStorage.getItem('InspectionToEdit')) || [];
            if (storageData.length == 0) {
                this.config.storageSave('InspectionToEdit', c);
            }
            // this.config.storageSave('InspectionToEdit', c); 
            const modal = yield this.modalController.create({
                cssClass: 'update-popup-modal',
                component: _app_modal_common_selection_common_selection_page__WEBPACK_IMPORTED_MODULE_8__["CommonSelectionPage"],
                componentProps: {
                    clientDetails: c,
                },
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    let d = dataReturned.data;
                    if (d.empty == 0) {
                        return;
                    }
                    if (d.empty == 1) {
                        this._userlogged_in = true;
                        let inps = JSON.parse(this.config.storageGet('CreateInspection')['__zone_symbol__value']);
                        console.log(inps);
                        this.InspectionDetail = inps.name;
                        return;
                    }
                    if (d.location) {
                    }
                }
            });
            return yield modal.present();
        });
    }
    GetContent() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.api.Get_data('getalldata/dev1@gmail.com/123').subscribe((res) => {
                // Loading_.dismiss();
                // console.log(JSON.stringify(res));
                this.config.commonContent = res;
                this.config._mergeAPIContentData();
            }, (err) => {
                // Loading_.dismiss();
                console.log(JSON.stringify(err));
            });
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _common_function__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map