(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["inspection-detail-inspection-detail-module"],{

/***/ "+UmD":
/*!***************************************************************!*\
  !*** ./src/app/inspection-detail/inspection-detail.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbnNwZWN0aW9uLWRldGFpbC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "fnaL":
/*!***********************************************************************!*\
  !*** ./src/app/inspection-detail/inspection-detail-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: InspectionDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionDetailPageRoutingModule", function() { return InspectionDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _inspection_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inspection-detail.page */ "vsUc");




const routes = [
    {
        path: '',
        component: _inspection_detail_page__WEBPACK_IMPORTED_MODULE_3__["InspectionDetailPage"]
    }
];
let InspectionDetailPageRoutingModule = class InspectionDetailPageRoutingModule {
};
InspectionDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InspectionDetailPageRoutingModule);



/***/ }),

/***/ "vsUc":
/*!*************************************************************!*\
  !*** ./src/app/inspection-detail/inspection-detail.page.ts ***!
  \*************************************************************/
/*! exports provided: InspectionDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionDetailPage", function() { return InspectionDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_inspection_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./inspection-detail.page.html */ "z51j");
/* harmony import */ var _inspection_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inspection-detail.page.scss */ "+UmD");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _common_function__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common.function */ "EU1L");





let InspectionDetailPage = class InspectionDetailPage {
    constructor(config) {
        this.config = config;
    }
    ngOnInit() { }
};
InspectionDetailPage.ctorParameters = () => [
    { type: _common_function__WEBPACK_IMPORTED_MODULE_4__["CommonService"] }
];
InspectionDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-inspection-detail',
        template: _raw_loader_inspection_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_inspection_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], InspectionDetailPage);



/***/ }),

/***/ "yT8p":
/*!***************************************************************!*\
  !*** ./src/app/inspection-detail/inspection-detail.module.ts ***!
  \***************************************************************/
/*! exports provided: InspectionDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InspectionDetailPageModule", function() { return InspectionDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _inspection_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./inspection-detail-routing.module */ "fnaL");
/* harmony import */ var _inspection_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./inspection-detail.page */ "vsUc");







let InspectionDetailPageModule = class InspectionDetailPageModule {
};
InspectionDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _inspection_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["InspectionDetailPageRoutingModule"]
        ],
        declarations: [_inspection_detail_page__WEBPACK_IMPORTED_MODULE_6__["InspectionDetailPage"]]
    })
], InspectionDetailPageModule);



/***/ }),

/***/ "z51j":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/inspection-detail/inspection-detail.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>inspection-detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <div class=\"list-icn\"></div>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=inspection-detail-inspection-detail-module.js.map