(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modal-structure-selection-structure-selection-module"],{

/***/ "4llt":
/*!*************************************************************************!*\
  !*** ./src/app/modal/structure-selection/structure-selection.module.ts ***!
  \*************************************************************************/
/*! exports provided: StructureSelectionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StructureSelectionPageModule", function() { return StructureSelectionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _structure_selection_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./structure-selection-routing.module */ "5sL0");
/* harmony import */ var _structure_selection_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./structure-selection.page */ "L4kz");







let StructureSelectionPageModule = class StructureSelectionPageModule {
};
StructureSelectionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _structure_selection_routing_module__WEBPACK_IMPORTED_MODULE_5__["StructureSelectionPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        ],
        declarations: [_structure_selection_page__WEBPACK_IMPORTED_MODULE_6__["StructureSelectionPage"]],
    })
], StructureSelectionPageModule);



/***/ }),

/***/ "5sL0":
/*!*********************************************************************************!*\
  !*** ./src/app/modal/structure-selection/structure-selection-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: StructureSelectionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StructureSelectionPageRoutingModule", function() { return StructureSelectionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _structure_selection_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./structure-selection.page */ "L4kz");




const routes = [
    {
        path: '',
        component: _structure_selection_page__WEBPACK_IMPORTED_MODULE_3__["StructureSelectionPage"]
    }
];
let StructureSelectionPageRoutingModule = class StructureSelectionPageRoutingModule {
};
StructureSelectionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StructureSelectionPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=modal-structure-selection-structure-selection-module.js.map