(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"],
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\"> </ion-buttons>\n    <ion-title> Home Inspection</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-item>\n      <ion-row style=\"text-align: center\">\n        <ion-col style=\"text-align: center\">\n          <ion-button\n            class=\"cus-top-selection-btn createins\"\n            (click)=\"CreateInspectionForm()\"\n          >\n            <span class=\"ot\">\n              <ion-icon class=\"add-circle-ic\" name=\"create-outline\"></ion-icon>\n            </span>\n            Create Inspection\n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-item>\n\n    <!-- <ion-item>\n      <ion-row>\n        <ion-col>\n          <div class=\"cus-top-selection-btn createins\" (click)=\"SavedPDFSHow()\">\n            <ion-icon class=\"add-circle-ic\" name=\"save-outline\"></ion-icon>\n\n            <p class=\"menu-txt\">Saved PDF</p>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-item> -->\n  </ion-list>\n\n  <div class=\"content-box\">\n    <div class=\"slide-box\" *ngFor=\"let m of allDocsCreated\">\n      <ion-row *ngFor=\"let c of m.client_Info\">\n        <ion-col size=\"6\" size-sm=\"6\">\n          <div class=\"content-one\">\n            <p class=\"subtitle-content\">Client Name</p>\n            <p class=\"text-info\">{{c.clientName}}</p>\n            <p class=\"subtitle-content\">Address</p>\n            <p class=\"text-info\">\n              <ion-icon\n                class=\"add-icn\"\n                name=\"navigate-circle-outline\"\n              ></ion-icon>\n              {{c.inspectionAddress}}\n            </p>\n            <p class=\"subtitle-content\">Inspector</p>\n            <p class=\"text-info\">{{c.inspector}}</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\" size-sm=\"6\">\n          <div class=\"content-two\">\n            <p class=\"subtitle-content\">Report Number</p>\n            <p class=\"text-info\">{{c.reportNumber}}</p>\n\n            <p class=\"subtitle-content\">Inspection Date</p>\n            <p class=\"text-info\">\n              {{c.inspectionDate | date: 'dd/MM/yyyy H:mm'}}\n            </p>\n          </div>\n\n          <div class=\"on-mid\">\n            <p class=\"title-btn\">\n              <button class=\"edit-btn\" (click)=\"openCommonModal(m)\">\n                Edit\n              </button>\n            </p>\n          </div>\n        </ion-col>\n        <!-- <ion-col size=\"12\" size-sm=\"6\" size-md=\"4\">\n          <div class=\"content-three\">\n            <div class=\"content-right\">\n          \n            </div>\n          </div>\n        </ion-col> -->\n      </ion-row>\n    </div>\n  </div>\n\n  <!-- <div class=\"container-home\">\n    <ion-row class=\"row-cls\" *ngFor=\"let m of allDocsCreated\">\n  \n\n      <div class=\"card-cus\" *ngFor=\"let c of m.client_Info\">\n        <ion-row>\n          <ion-col>\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Client Name</p>\n              <p class=\"hz-txt\">{{c.clientName}}</p>\n            </div>\n\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">inspectionAddress</p>\n              <p class=\"hz-txt\">{{c.inspectionAddress}}</p>\n            </div>\n          </ion-col>\n\n          <ion-col>\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Inspector</p>\n              <p class=\"hz-txt\">{{c.inspector}}</p>\n            </div>\n\n            <div class=\"cont-txt-lb\">\n              <p class=\"lb-txt\">Report Number</p>\n              <p class=\"hz-txt\">{{c.reportNumber}}</p>\n            </div>\n          </ion-col>\n        </ion-row>\n\n        <div class=\"date-only\">\n          <p class=\"lb-txt\">Inspection Date</p>\n          <p class=\"date-field\">{{c.inspectionDate}}</p>\n        </div>\n      </div>\n\n      <button class=\"edit-button2\" (click)=\"openCommonModal(m)\">\n        <ion-icon class=\"edit-icn2\" name=\"create-outline\"></ion-icon>\n      </button>\n    </ion-row>\n  </div> -->\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-cus {\n  margin-left: 20px;\n  margin-right: 20px;\n}\n\np.lb-txt {\n  font-size: 12px;\n}\n\np.hz-txt {\n  margin-top: -9px;\n}\n\np.date-field {\n  margin-top: -9px;\n}\n\nion-icon.icn-top.ios.hydrated {\n  margin-right: 7px;\n}\n\nion-icon.icn-top.md.hydrated {\n  margin-right: 7px;\n}\n\nion-button.cus-top-selection-btn.createins.ios.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --border-radius: 11px;\n  text-transform: capitalize;\n}\n\nion-button.cus-top-selection-btn.createins.md.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --border-radius: 11px;\n  text-transform: capitalize;\n}\n\nspan.ot {\n  border-right: 1px solid;\n  margin-right: 6px;\n}\n\nbutton.edit-btn {\n  float: right;\n  margin-top: 9px;\n  margin-right: 17px;\n  display: flex;\n  border-radius: 17px;\n  font-size: 16px;\n  padding-left: 5px;\n  padding-top: 3px;\n  padding-bottom: 3px;\n  padding-right: 7px;\n  color: #222428;\n}\n\nion-icon.edit-icn.md.hydrated {\n  color: #222428;\n  font-size: 18px;\n  margin-top: -2px;\n}\n\nion-icon.edit-icn.ios.hydrated {\n  color: #222428;\n  font-size: 18px;\n  margin-top: -2px;\n}\n\nion-row.row-cls.md.hydrated {\n  background: white;\n  padding-left: 12px;\n  width: 100%;\n  margin-top: 20px;\n  border-radius: 10px;\n  box-shadow: 10px 10px 5px 0px #d7d8da;\n  -webkit-box-shadow: 10px 10px 5px 0px #989aa2;\n  -moz-box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n  color: black;\n  margin-left: 14px;\n}\n\n.cus-top-selection-btn.createins {\n  display: inline-flex;\n}\n\nion-row.row-cls.ios.hydrated {\n  background: white;\n  padding-left: 12px;\n  width: 100%;\n  margin-top: 20px;\n  border-radius: 10px;\n  box-shadow: 10px 10px 5px 0px #d7d8da;\n  -webkit-box-shadow: 10px 10px 5px 0px #989aa2;\n  -moz-box-shadow: 10px 10px 5px 0px rgba(0, 0, 0, 0.75);\n  color: black;\n  margin-left: 14px;\n}\n\nion-icon.add-circle-ic.md.hydrated {\n  margin-top: 2px;\n  margin-right: 4px;\n  font-size: 16px;\n}\n\nion-content.md.hydrated {\n  --background: #f2f2f2;\n}\n\nion-content.ios.hydrated {\n  --background: #f2f2f2;\n}\n\nion-icon.add-circle-ic.ios.hydrated {\n  margin-top: 2px;\n  margin-right: 4px;\n  font-size: 16px;\n}\n\n.date-only {\n  margin-top: -25px;\n}\n\n.content-box {\n  background-repeat: no-repeat, repeat;\n  background-position: right top;\n  background-image: url('background-rect.png');\n  background-attachment: fixed;\n}\n\n.slide-box {\n  margin-left: 10px;\n  margin-right: 10px;\n  margin-top: 19px;\n  margin-bottom: 25px;\n  background: white;\n  border-radius: 30px;\n}\n\n@media only screen and (min-width: 900px) {\n  .slide-box {\n    width: 75% !important;\n  }\n\n  .slide-box.singleorder {\n    width: 93% !important;\n    margin-left: 27px;\n  }\n\n  button.edit-btn {\n    position: fixed;\n    top: 10;\n    top: 110px !important;\n    right: 0px;\n    margin-right: 31px;\n  }\n}\n\nbutton.edit-btn {\n  position: revert;\n  top: 10;\n  top: auto;\n  right: auto;\n  margin-right: auto;\n}\n\n.content-one {\n  padding-left: 22px;\n}\n\np.c-title {\n  color: #193f6a;\n  background: #f5f5f5;\n  text-align: center;\n  height: 27px;\n  padding-top: 4px;\n  font-size: 16px;\n  border-radius: 60px;\n  margin-top: 12px;\n  margin-bottom: 25px;\n  padding-left: 10px;\n  padding-right: 10px;\n  width: 126px;\n  overflow: hidden;\n  height: 24px;\n  padding-bottom: 19px;\n}\n\np.subtitle-content {\n  font-size: 11px;\n  margin-bottom: -19px;\n  font-family: \"Poppins\";\n  color: #193f6aab;\n  font-family: \"Poppins\";\n}\n\np.text-info {\n  line-height: 18px;\n}\n\np.text-info {\n  color: #193f6a;\n  font-family: \"Poppins\";\n  font-size: 15px;\n  margin-bottom: 17px;\n  margin-top: 18px;\n}\n\n.content-two {\n  margin-top: 62px;\n}\n\n@media only screen and (max-width: 720px) {\n  .slide-box {\n    background-repeat: no-repeat, repeat;\n    background-position: bottom center;\n    background-image: url('group-circles.png') !important;\n  }\n\n  .on-mid {\n    margin-top: 0px !important;\n    padding-left: 22px !important;\n  }\n\n  .content-two {\n    margin-top: 0px !important;\n    padding-left: 22px !important;\n  }\n\n  .content-three {\n    padding-left: 4px !important;\n    padding-bottom: 13px;\n  }\n}\n\np.title-btn {\n  float: right;\n}\n\nion-button.cus-top-selection-btn.createins.md.button.button-small.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n}\n\nion-button.cus-top-selection-btn.createins.ios.button.button-small.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQVdBO0VBQ0UsZUFBQTtBQVJGOztBQVdBO0VBQ0UsZ0JBQUE7QUFSRjs7QUFXQTtFQUNFLGdCQUFBO0FBUkY7O0FBV0E7RUFDRSxpQkFBQTtBQVJGOztBQVdBO0VBQ0UsaUJBQUE7QUFSRjs7QUFXQTtFQUNFLHFCQUFBO0VBQ0EsMEJBQUE7QUFSRjs7QUFXQTtFQUNFLHFCQUFBO0VBQ0EsMEJBQUE7QUFSRjs7QUFXQTtFQUNFLHVCQUFBO0VBRUEsaUJBQUE7QUFURjs7QUFZQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBVEY7O0FBWUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBVEY7O0FBWUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtFQUNBLDZDQUFBO0VBQ0Esc0RBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFURjs7QUFZQTtFQUNFLG9CQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtFQUNBLDZDQUFBO0VBQ0Esc0RBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFURjs7QUFZQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFURjs7QUFZQTtFQUNFLHFCQUFBO0FBVEY7O0FBWUE7RUFDRSxxQkFBQTtBQVRGOztBQVlBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQVRGOztBQVlBO0VBQ0UsaUJBQUE7QUFURjs7QUFZQTtFQUNFLG9DQUFBO0VBQ0EsOEJBQUE7RUFDQSw0Q0FBQTtFQUNBLDRCQUFBO0FBVEY7O0FBWUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFURjs7QUFZQTtFQUNFO0lBQ0UscUJBQUE7RUFURjs7RUFXQTtJQUNFLHFCQUFBO0lBQ0EsaUJBQUE7RUFSRjs7RUFVQTtJQUNFLGVBQUE7SUFDQSxPQUFBO0lBQ0EscUJBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUFQRjtBQUNGOztBQVVBO0VBQ0UsZ0JBQUE7RUFDQSxPQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQVJGOztBQVdBO0VBQ0Usa0JBQUE7QUFSRjs7QUFXQTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBRUEsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUFURjs7QUFZQTtFQUNFLGVBQUE7RUFDQSxvQkFBQTtFQUVBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQVZGOztBQWFBO0VBQ0UsaUJBQUE7QUFWRjs7QUFhQTtFQUNFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBVkY7O0FBYUE7RUFDRSxnQkFBQTtBQVZGOztBQWFBO0VBQ0U7SUFDRSxvQ0FBQTtJQUNBLGtDQUFBO0lBQ0EscURBQUE7RUFWRjs7RUFhQTtJQUNFLDBCQUFBO0lBQ0EsNkJBQUE7RUFWRjs7RUFhQTtJQUNFLDBCQUFBO0lBQ0EsNkJBQUE7RUFWRjs7RUFhQTtJQUNFLDRCQUFBO0lBQ0Esb0JBQUE7RUFWRjtBQUNGOztBQWFBO0VBQ0UsWUFBQTtBQVhGOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSwrQkFBQTtBQVhGOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSwrQkFBQTtBQVhGIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQtY3VzIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIG1hcmdpbi1yaWdodDogMjBweDtcbiAgLy8gYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAvLyBwYWRkaW5nLWxlZnQ6IDEycHg7XG4gIC8vIHdpZHRoOiAxMDAlO1xuICAvLyBtYXJnaW4tdG9wOiAyMHB4O1xuICAvLyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAvLyBib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCAjZDdkOGRhO1xuICAvLyAtd2Via2l0LWJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4ICM5ODlhYTI7XG4gIC8vIC1tb3otYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggcmdiYSgwLCAwLCAwLCAwLjc1KTtcbiAgLy8gY29sb3I6ICNmZmZmZmZhYjtcbn1cblxucC5sYi10eHQge1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbnAuaHotdHh0IHtcbiAgbWFyZ2luLXRvcDogLTlweDtcbn1cblxucC5kYXRlLWZpZWxkIHtcbiAgbWFyZ2luLXRvcDogLTlweDtcbn1cblxuaW9uLWljb24uaWNuLXRvcC5pb3MuaHlkcmF0ZWQge1xuICBtYXJnaW4tcmlnaHQ6IDdweDtcbn1cblxuaW9uLWljb24uaWNuLXRvcC5tZC5oeWRyYXRlZCB7XG4gIG1hcmdpbi1yaWdodDogN3B4O1xufVxuXG5pb24tYnV0dG9uLmN1cy10b3Atc2VsZWN0aW9uLWJ0bi5jcmVhdGVpbnMuaW9zLmJ1dHRvbi5idXR0b24tc29saWQuaW9uLWFjdGl2YXRhYmxlLmlvbi1mb2N1c2FibGUuaHlkcmF0ZWQge1xuICAtLWJvcmRlci1yYWRpdXM6IDExcHg7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuXG5pb24tYnV0dG9uLmN1cy10b3Atc2VsZWN0aW9uLWJ0bi5jcmVhdGVpbnMubWQuYnV0dG9uLmJ1dHRvbi1zb2xpZC5pb24tYWN0aXZhdGFibGUuaW9uLWZvY3VzYWJsZS5oeWRyYXRlZCB7XG4gIC0tYm9yZGVyLXJhZGl1czogMTFweDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59XG5cbnNwYW4ub3Qge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZDtcblxuICBtYXJnaW4tcmlnaHQ6IDZweDtcbn1cblxuYnV0dG9uLmVkaXQtYnRuIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiA5cHg7XG4gIG1hcmdpbi1yaWdodDogMTdweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyLXJhZGl1czogMTdweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgcGFkZGluZy10b3A6IDNweDtcbiAgcGFkZGluZy1ib3R0b206IDNweDtcbiAgcGFkZGluZy1yaWdodDogN3B4O1xuICBjb2xvcjogIzIyMjQyODtcbn1cblxuaW9uLWljb24uZWRpdC1pY24ubWQuaHlkcmF0ZWQge1xuICBjb2xvcjogIzIyMjQyODtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW4tdG9wOiAtMnB4O1xufVxuXG5pb24taWNvbi5lZGl0LWljbi5pb3MuaHlkcmF0ZWQge1xuICBjb2xvcjogIzIyMjQyODtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW4tdG9wOiAtMnB4O1xufVxuXG5pb24tcm93LnJvdy1jbHMubWQuaHlkcmF0ZWQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggI2Q3ZDhkYTtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCAjOTg5YWEyO1xuICAtbW96LWJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4IHJnYmEoMCwgMCwgMCwgMC43NSk7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IDE0cHg7XG59XG5cbi5jdXMtdG9wLXNlbGVjdGlvbi1idG4uY3JlYXRlaW5zIHtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG59XG5cbmlvbi1yb3cucm93LWNscy5pb3MuaHlkcmF0ZWQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYm94LXNoYWRvdzogMTBweCAxMHB4IDVweCAwcHggI2Q3ZDhkYTtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAxMHB4IDEwcHggNXB4IDBweCAjOTg5YWEyO1xuICAtbW96LWJveC1zaGFkb3c6IDEwcHggMTBweCA1cHggMHB4IHJnYmEoMCwgMCwgMCwgMC43NSk7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IDE0cHg7XG59XG5cbmlvbi1pY29uLmFkZC1jaXJjbGUtaWMubWQuaHlkcmF0ZWQge1xuICBtYXJnaW4tdG9wOiAycHg7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbmlvbi1jb250ZW50Lm1kLmh5ZHJhdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjJmMmYyO1xufVxuXG5pb24tY29udGVudC5pb3MuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjI7XG59XG5cbmlvbi1pY29uLmFkZC1jaXJjbGUtaWMuaW9zLmh5ZHJhdGVkIHtcbiAgbWFyZ2luLXRvcDogMnB4O1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uZGF0ZS1vbmx5IHtcbiAgbWFyZ2luLXRvcDogLTI1cHg7XG59XG5cbi5jb250ZW50LWJveCB7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQsIHJlcGVhdDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogcmlnaHQgdG9wO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL1Jlcy9iYWNrZ3JvdW5kLXJlY3QucG5nKTtcbiAgYmFja2dyb3VuZC1hdHRhY2htZW50OiBmaXhlZDtcbn1cblxuLnNsaWRlLWJveCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi10b3A6IDE5cHg7XG4gIG1hcmdpbi1ib3R0b206IDI1cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDkwMHB4KSB7XG4gIC5zbGlkZS1ib3gge1xuICAgIHdpZHRoOiA3NSUgIWltcG9ydGFudDtcbiAgfVxuICAuc2xpZGUtYm94LnNpbmdsZW9yZGVyIHtcbiAgICB3aWR0aDogOTMlICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDI3cHg7XG4gIH1cbiAgYnV0dG9uLmVkaXQtYnRuIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAxMDtcbiAgICB0b3A6IDExMHB4ICFpbXBvcnRhbnQ7XG4gICAgcmlnaHQ6IDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDMxcHg7XG4gIH1cbn1cblxuYnV0dG9uLmVkaXQtYnRuIHtcbiAgcG9zaXRpb246IHJldmVydDtcbiAgdG9wOiAxMDtcbiAgdG9wOiBhdXRvO1xuICByaWdodDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuXG4uY29udGVudC1vbmUge1xuICBwYWRkaW5nLWxlZnQ6IDIycHg7XG59XG5cbnAuYy10aXRsZSB7XG4gIGNvbG9yOiAjMTkzZjZhO1xuICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogMjdweDtcbiAgcGFkZGluZy10b3A6IDRweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBib3JkZXItcmFkaXVzOiA2MHB4O1xuXG4gIG1hcmdpbi10b3A6IDEycHg7XG4gIG1hcmdpbi1ib3R0b206IDI1cHg7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgd2lkdGg6IDEyNnB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBoZWlnaHQ6IDI0cHg7XG4gIHBhZGRpbmctYm90dG9tOiAxOXB4O1xufVxuXG5wLnN1YnRpdGxlLWNvbnRlbnQge1xuICBmb250LXNpemU6IDExcHg7XG4gIG1hcmdpbi1ib3R0b206IC0xOXB4O1xuXG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbiAgY29sb3I6ICMxOTNmNmFhYjtcbiAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiO1xufVxuXG5wLnRleHQtaW5mbyB7XG4gIGxpbmUtaGVpZ2h0OiAxOHB4O1xufVxuXG5wLnRleHQtaW5mbyB7XG4gIGNvbG9yOiAjMTkzZjZhO1xuICBmb250LWZhbWlseTogXCJQb3BwaW5zXCI7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogMTdweDtcbiAgbWFyZ2luLXRvcDogMThweDtcbn1cblxuLmNvbnRlbnQtdHdvIHtcbiAgbWFyZ2luLXRvcDogNjJweDtcbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MjBweCkge1xuICAuc2xpZGUtYm94IHtcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0LCByZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogYm90dG9tIGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL1Jlcy9ncm91cC1jaXJjbGVzLnBuZykgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5vbi1taWQge1xuICAgIG1hcmdpbi10b3A6IDBweCAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmctbGVmdDogMjJweCAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmNvbnRlbnQtdHdvIHtcbiAgICBtYXJnaW4tdG9wOiAwcHggIWltcG9ydGFudDtcbiAgICBwYWRkaW5nLWxlZnQ6IDIycHggIWltcG9ydGFudDtcbiAgfVxuXG4gIC5jb250ZW50LXRocmVlIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDRweCAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmctYm90dG9tOiAxM3B4O1xuICB9XG59XG5cbnAudGl0bGUtYnRuIHtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG5pb24tYnV0dG9uLmN1cy10b3Atc2VsZWN0aW9uLWJ0bi5jcmVhdGVpbnMubWQuYnV0dG9uLmJ1dHRvbi1zbWFsbC5idXR0b24tc29saWQuaW9uLWFjdGl2YXRhYmxlLmlvbi1mb2N1c2FibGUuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1idXR0b24uY3VzLXRvcC1zZWxlY3Rpb24tYnRuLmNyZWF0ZWlucy5pb3MuYnV0dG9uLmJ1dHRvbi1zbWFsbC5idXR0b24tc29saWQuaW9uLWFjdGl2YXRhYmxlLmlvbi1mb2N1c2FibGUuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4iXX0= */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _common_function__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common.function */ "EU1L");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../api.service */ "yTNM");
/* harmony import */ var _app_modal_create_inspection_create_inspection_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../app/modal/create-inspection/create-inspection.page */ "0ucC");
/* harmony import */ var _app_modal_common_selection_common_selection_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../app/modal/common-selection/common-selection.page */ "xVOy");










let HomePage = class HomePage {
    constructor(alertController, loadingController, config, api, modalController, platform) {
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.config = config;
        this.api = api;
        this.modalController = modalController;
        this.platform = platform;
        this.SavedPDFshow = false;
        this._userlogged_in = false;
        this.allDocsCreated = [];
        // this.config.storageSave('InspectionsCreated', this.allDocsCreated);
        // let newVr = [];
        // newVr.push(this.allDocsCreated);
        // newVr.push(InspectionsCreated);
        // console.log('New Vr=====' + JSON.stringify(newVr));
    }
    ionViewDidEnter() {
        let commArr = [];
        // this.config.storageRemoveItem('InspectionToEdit');
        // let vr = this.config.storageSave('InspectionToEdit', commArr);
        let InspectionsCreated = JSON.parse(this.config.storageGet('InspectionsCreated')['__zone_symbol__value']);
        // this.config.storageRemoveItem('InspectionsCreated');
        commArr = InspectionsCreated;
        console.log(JSON.stringify(commArr));
        if (InspectionsCreated == null) {
            console.log('NULL');
            this.allDocsCreated = this.config.AllDumyDocs;
        }
        else {
            console.log('NotNull');
            let InspectionsCreated = JSON.parse(this.config.storageGet('InspectionsCreated')['__zone_symbol__value']);
            // this.allDocsCreated = this.config.AllDumyDocs;
            // this.allDocsCreated = InspectionsCreated;
            this.allDocsCreated = commArr;
        }
    }
    CreateInspectionForm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.config.storageRemoveItem('InspectionToEdit');
            const modal = yield this.modalController.create({
                cssClass: 'update-popup-modal',
                component: _app_modal_create_inspection_create_inspection_page__WEBPACK_IMPORTED_MODULE_7__["CreateInspectionPage"],
                componentProps: {},
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    let d = dataReturned.data;
                    if (d.empty == 0) {
                        return;
                    }
                    if (d.empty == 1) {
                        this._userlogged_in = true;
                        let inps = JSON.parse(this.config.storageGet('CreateInspection')['__zone_symbol__value']);
                        console.log(inps);
                        this.InspectionDetail = inps.name;
                        return;
                    }
                    if (d.location) {
                    }
                }
            });
            return yield modal.present();
        });
    }
    SavedPDFSHow() {
        this.SavedPDFshow = !this.SavedPDFshow;
    }
    doRefresh() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log('Begin async operation');
            setTimeout(() => {
                console.log('Async operation has ended');
                this.api.Get_data('getalldata/dev1@gmail.com/123').subscribe((res) => {
                    // Loading_.dismiss();
                    // console.log(JSON.stringify(res));
                    this.config.commonContent = res;
                    this.config._mergeAPIContentData();
                }, (err) => {
                    // Loading_.dismiss();
                    console.log(JSON.stringify(err));
                });
                // event.target.complete();
            }, 4000);
        });
    }
    openCommonModal(c) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.doRefresh();
            this.config.storageRemoveItem('InspectionsCreated');
            // this.config.storageRemoveItem('InspectionToEdit');
            const storageData = JSON.parse(localStorage.getItem('InspectionToEdit')) || [];
            if (storageData.length == 0) {
                this.config.storageSave('InspectionToEdit', c);
            }
            // this.config.storageSave('InspectionToEdit', c); 
            const modal = yield this.modalController.create({
                cssClass: 'update-popup-modal',
                component: _app_modal_common_selection_common_selection_page__WEBPACK_IMPORTED_MODULE_8__["CommonSelectionPage"],
                componentProps: {
                    clientDetails: c,
                },
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    let d = dataReturned.data;
                    if (d.empty == 0) {
                        return;
                    }
                    if (d.empty == 1) {
                        this._userlogged_in = true;
                        let inps = JSON.parse(this.config.storageGet('CreateInspection')['__zone_symbol__value']);
                        console.log(inps);
                        this.InspectionDetail = inps.name;
                        return;
                    }
                    if (d.location) {
                    }
                }
            });
            return yield modal.present();
        });
    }
    GetContent() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.api.Get_data('getalldata/dev1@gmail.com/123').subscribe((res) => {
                // Loading_.dismiss();
                // console.log(JSON.stringify(res));
                this.config.commonContent = res;
                this.config._mergeAPIContentData();
            }, (err) => {
                // Loading_.dismiss();
                console.log(JSON.stringify(err));
            });
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _common_function__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map