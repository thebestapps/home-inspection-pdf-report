(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modal-create-inspection-create-inspection-module"],{

/***/ "PgCR":
/*!*****************************************************************************!*\
  !*** ./src/app/modal/create-inspection/create-inspection-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: CreateInspectionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateInspectionPageRoutingModule", function() { return CreateInspectionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_inspection_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-inspection.page */ "0ucC");




const routes = [
    {
        path: '',
        component: _create_inspection_page__WEBPACK_IMPORTED_MODULE_3__["CreateInspectionPage"]
    }
];
let CreateInspectionPageRoutingModule = class CreateInspectionPageRoutingModule {
};
CreateInspectionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateInspectionPageRoutingModule);



/***/ }),

/***/ "dCXs":
/*!*********************************************************************!*\
  !*** ./src/app/modal/create-inspection/create-inspection.module.ts ***!
  \*********************************************************************/
/*! exports provided: CreateInspectionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateInspectionPageModule", function() { return CreateInspectionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_inspection_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-inspection-routing.module */ "PgCR");
/* harmony import */ var _create_inspection_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-inspection.page */ "0ucC");






// import { File } from '@ionic-native/file/ngx';
// import { FileOpener } from '@ionic-native/file-opener/ngx';

let CreateInspectionPageModule = class CreateInspectionPageModule {
};
CreateInspectionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _create_inspection_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateInspectionPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        ],
        providers: [],
        declarations: [_create_inspection_page__WEBPACK_IMPORTED_MODULE_6__["CreateInspectionPage"]],
    })
], CreateInspectionPageModule);



/***/ })

}]);
//# sourceMappingURL=modal-create-inspection-create-inspection-module.js.map