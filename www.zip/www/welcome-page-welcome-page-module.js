(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["welcome-page-welcome-page-module"],{

/***/ "5XYs":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/welcome-page/welcome-page.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>Home Inspection System</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"container2\">\n    <ion-row>\n      <div class=\"contain-logo\">\n        <img src=\"../../assets/logo-only.png\" class=\"logoimg\" />\n      </div>\n    </ion-row>\n\n\n<div class=\"btm\">\n\n        <ion-button class=\"cont-btn\" (click)=\"GoNavig()\"> Continue </ion-button>\n      </div>\n  </div>\n</ion-content>\n -->\n\n<!--<ion-header mode=\"ios\">-->\n<!--  <ion-toolbar>-->\n<!--    <ion-title class=\"ion-text-center\">Walkthrough</ion-title>-->\n<!--  </ion-toolbar>-->\n<!--</ion-header>-->\n\n<ion-content>\n  <ion-slides\n    #slides\n    pager=\"true\"\n    [options]=\"slideOpts\"\n    (ionSlideWillChange)=\"getIndex($event)\"\n  >\n    <ion-slide>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <img src=\"../../assets/logo-only.png\" />\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col>\n            <p class=\"title\">Home Inspection System</p>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-slide>\n    <ion-slide>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <img class=\"img-src\" src=\"../../assets/Res/CreatePdf1.png\" />\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"txt-header\"></ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"slide-content\">Create PDF</ion-label>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-slide>\n    <ion-slide>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <img class=\"img-src2\" src=\"../../assets/Res/st2.jpg\" />\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"txt-header\"></ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"slide-content\">Customize Report</ion-label>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-slide>\n    <ion-slide>\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <img class=\"img-src\" src=\"../../assets/Res/st3.jpg\" />\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"txt-header\"></ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label class=\"txt-header\">Get Started</ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <!-- <ion-label class=\"slide-content\"></ion-label> -->\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-slide>\n  </ion-slides>\n</ion-content>\n\n<ion-footer mode=\"ios\" no-border>\n  <ion-row>\n    <ion-col style=\"text-align: center\">\n      <ion-button class=\"customButton\" (click)=\"GoNavig()\"\n        >{{slideLast? 'Start' : 'Skip' }}</ion-button\n      >\n    </ion-col>\n    <ion-col style=\"text-align: center\">\n      <ion-button\n        class=\"customButton Next\"\n        (click)=\"slides.slideNext()\"\n        [disabled]=\"slideLast\"\n        >Next</ion-button\n      >\n    </ion-col>\n  </ion-row>\n</ion-footer>\n");

/***/ }),

/***/ "FSnL":
/*!*************************************************************!*\
  !*** ./src/app/welcome-page/welcome-page-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: WelcomePagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePagePageRoutingModule", function() { return WelcomePagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _welcome_page_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./welcome-page.page */ "Tjpd");




const routes = [
    {
        path: '',
        component: _welcome_page_page__WEBPACK_IMPORTED_MODULE_3__["WelcomePagePage"]
    }
];
let WelcomePagePageRoutingModule = class WelcomePagePageRoutingModule {
};
WelcomePagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], WelcomePagePageRoutingModule);



/***/ }),

/***/ "G4WV":
/*!*****************************************************!*\
  !*** ./src/app/welcome-page/welcome-page.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-slides {\n  height: 100%;\n}\n\nion-button.customButton.Next.ios.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n  -border: 1px solid var(--ion-color-primary);\n}\n\nion-button.customButton.Next.md.button.button-solid.ion-activatable.ion-focusable.hydrated {\n  --background: none;\n  color: var(--ion-color-primary);\n  -border: 1px solid var(--ion-color-primary);\n}\n\n.customButton:hover {\n  --background: var(--ion-color-primary);\n  box-shadow: -10px -10px 20px rgba(56, 58, 58, 0.91), 10px 10px 20px rgba(17, 28, 26, 0.91);\n  border-radius: 11px;\n  margin-right: auto;\n  margin-left: auto;\n  height: 33px;\n  font-size: 16px;\n  --border-radius: 11px;\n  text-transform: capitalize;\n  font-family: \"Avenir\";\n  color: white;\n  margin-bottom: 22px;\n}\n\n.customButton {\n  width: 55%;\n  --background: var(--ion-color-primary);\n  border-radius: 11px;\n  margin-right: auto;\n  margin-left: auto;\n  height: 33px;\n  font-size: 16px;\n  margin-bottom: 10px;\n  text-transform: capitalize;\n  font-family: \"Avenir\";\n  color: white;\n  margin-bottom: 22px;\n  --border-radius: 11px;\n}\n\nion-label.sc-ion-label-md-h.sc-ion-label-md-s.md.hydrated {\n  line-height: 27px;\n  font-family: \"Avenir\";\n}\n\nion-label.sc-ion-label-ios-h.sc-ion-label-ios-s.ios.hydrated {\n  line-height: 27px;\n  font-family: \"Avenir\";\n}\n\nion-row.md.hydrated {\n  background: #fff;\n  width: 84%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-row.ios.hydrated {\n  background: #fff;\n  width: 84%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-row.label-intro.md.hydrated {\n  background: #fff;\n  width: 84%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-row.label-intro.ios.hydrated {\n  background: #fff;\n  width: 84%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-label.txt-header.sc-ion-label-md-h.sc-ion-label-md-s.md.hydrated {\n  font-family: \"Avenir\";\n}\n\nion-label.txt-header.sc-ion-label-ios-h.sc-ion-label-ios-s.ios.hydrated {\n  font-family: \"Avenir\";\n}\n\nion-grid.md.hydrated {\n  top: 12%;\n  position: fixed;\n  width: 100%;\n}\n\nion-grid.ios.hydrated {\n  top: 12%;\n  position: fixed;\n  width: 100%;\n}\n\nion-button.skip-btn.ios.button.button-full.button-solid.ion-activatable.ion-focusable.hydrated {\n  color: #0267ff;\n  text-transform: uppercase;\n  font-family: \"Avenir\";\n}\n\nion-button.skip-btn.md.button.button-full.button-solid.ion-activatable.ion-focusable.hydrated {\n  color: #0267ff;\n  text-transform: uppercase;\n  font-family: \"Avenir\";\n}\n\nion-slide.md.swiper-slide.swiper-zoom-container.hydrated.swiper-slide-active {\n  height: 86%;\n  border-radius: 36px;\n  width: 91% !important;\n  margin-left: 16px;\n  margin-top: 15px;\n  margin-right: 10px;\n}\n\nion-slide.ios.swiper-slide.swiper-zoom-container.hydrated.swiper-slide-active {\n  height: 86%;\n  border-radius: 36px;\n  width: 91% !important;\n  margin-left: 16px;\n  margin-top: 15px;\n  margin-right: 10px;\n}\n\n@media only screen and (max-height: 429px) {\n  img {\n    height: 171px !important;\n  }\n}\n\nion-content.ios.hydrated {\n  --background: white;\n}\n\nion-content.md.hydrated {\n  --background: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3dlbGNvbWUtcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBaUJBO0VBQ0UsWUFBQTtBQWhCRjs7QUFtQkE7RUFDRSxrQkFBQTtFQUNBLCtCQUFBO0VBRUEsMkNBQUE7QUFqQkY7O0FBb0JBO0VBQ0Usa0JBQUE7RUFDQSwrQkFBQTtFQUVBLDJDQUFBO0FBbEJGOztBQXFCQTtFQUNFLHNDQUFBO0VBQ0EsMEZBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBRUEsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQXBCRjs7QUF1QkE7RUFDRSxVQUFBO0VBQ0Esc0NBQUE7RUFFQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FBckJGOztBQXdCQTtFQUNFLGlCQUFBO0VBQ0EscUJBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsaUJBQUE7RUFDQSxxQkFBQTtBQXJCRjs7QUF3QkE7RUFDRSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBckJGOztBQXdCQTtFQUNFLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQXJCRjs7QUF3QkE7RUFDRSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBckJGOztBQXdCQTtFQUNFLHFCQUFBO0FBckJGOztBQXdCQTtFQUNFLHFCQUFBO0FBckJGOztBQXdCQTtFQUNFLFFBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQXJCRjs7QUF3QkE7RUFDRSxRQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsY0FBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsY0FBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFyQkY7O0FBd0JBO0VBQ0U7SUFDRSx3QkFBQTtFQXJCRjtBQUNGOztBQXVCQTtFQUNFLG1CQUFBO0FBckJGOztBQXdCQTtFQUNFLG1CQUFBO0FBckJGIiwiZmlsZSI6IndlbGNvbWUtcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyAuY29udGFpbi1sb2dvIHtcbi8vICAgbWFyZ2luLWxlZnQ6IGF1dG87XG4vLyAgIG1hcmdpbi1yaWdodDogYXV0bztcbi8vIH1cblxuLy8gaW1nLmxvZ29pbWcge1xuLy8gICBtYXJnaW4tdG9wOiAzN3B4O1xuLy8gfVxuXG4vLyBpb24tY29udGVudC5tZC5oeWRyYXRlZCB7XG4vLyAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4vLyB9XG5cbi8vIGlvbi1jb250ZW50Lmlvcy5oeWRyYXRlZCB7XG4vLyAgIC0tYmFja2dyb3VuZDogd2hpdGU7XG4vLyB9XG5cbmlvbi1zbGlkZXMge1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbmlvbi1idXR0b24uY3VzdG9tQnV0dG9uLk5leHQuaW9zLmJ1dHRvbi5idXR0b24tc29saWQuaW9uLWFjdGl2YXRhYmxlLmlvbi1mb2N1c2FibGUuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG5cbiAgLWJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLWJ1dHRvbi5jdXN0b21CdXR0b24uTmV4dC5tZC5idXR0b24uYnV0dG9uLXNvbGlkLmlvbi1hY3RpdmF0YWJsZS5pb24tZm9jdXNhYmxlLmh5ZHJhdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuXG4gIC1ib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbi5jdXN0b21CdXR0b246aG92ZXIge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYm94LXNoYWRvdzogLTEwcHggLTEwcHggMjBweCByZ2IoNTYgNTggNTggLyA5MSUpLFxuICAgIDEwcHggMTBweCAyMHB4IHJnYigxNyAyOCAyNiAvIDkxJSk7XG4gIGJvcmRlci1yYWRpdXM6IDExcHg7XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIGhlaWdodDogMzNweDtcblxuICBmb250LXNpemU6IDE2cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogMTFweDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIGZvbnQtZmFtaWx5OiBcIkF2ZW5pclwiO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi1ib3R0b206IDIycHg7XG59XG5cbi5jdXN0b21CdXR0b24ge1xuICB3aWR0aDogNTUlO1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgLy8gYm94LXNoYWRvdzogLTEwcHggLTEwcHggMjBweCAjZWM3NjNkLCAxMHB4IDEwcHggMjBweCAjZWM3NjNkO1xuICBib3JkZXItcmFkaXVzOiAxMXB4O1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBoZWlnaHQ6IDMzcHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIGZvbnQtZmFtaWx5OiBcIkF2ZW5pclwiO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi1ib3R0b206IDIycHg7XG4gIC0tYm9yZGVyLXJhZGl1czogMTFweDtcbn1cblxuaW9uLWxhYmVsLnNjLWlvbi1sYWJlbC1tZC1oLnNjLWlvbi1sYWJlbC1tZC1zLm1kLmh5ZHJhdGVkIHtcbiAgbGluZS1oZWlnaHQ6IDI3cHg7XG4gIGZvbnQtZmFtaWx5OiBcIkF2ZW5pclwiO1xufVxuXG5pb24tbGFiZWwuc2MtaW9uLWxhYmVsLWlvcy1oLnNjLWlvbi1sYWJlbC1pb3Mtcy5pb3MuaHlkcmF0ZWQge1xuICBsaW5lLWhlaWdodDogMjdweDtcbiAgZm9udC1mYW1pbHk6IFwiQXZlbmlyXCI7XG59XG5cbmlvbi1yb3cubWQuaHlkcmF0ZWQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB3aWR0aDogODQlO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuXG5pb24tcm93Lmlvcy5oeWRyYXRlZCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHdpZHRoOiA4NCU7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG5cbmlvbi1yb3cubGFiZWwtaW50cm8ubWQuaHlkcmF0ZWQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB3aWR0aDogODQlO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuXG5pb24tcm93LmxhYmVsLWludHJvLmlvcy5oeWRyYXRlZCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHdpZHRoOiA4NCU7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG5cbmlvbi1sYWJlbC50eHQtaGVhZGVyLnNjLWlvbi1sYWJlbC1tZC1oLnNjLWlvbi1sYWJlbC1tZC1zLm1kLmh5ZHJhdGVkIHtcbiAgZm9udC1mYW1pbHk6IFwiQXZlbmlyXCI7XG59XG5cbmlvbi1sYWJlbC50eHQtaGVhZGVyLnNjLWlvbi1sYWJlbC1pb3MtaC5zYy1pb24tbGFiZWwtaW9zLXMuaW9zLmh5ZHJhdGVkIHtcbiAgZm9udC1mYW1pbHk6IFwiQXZlbmlyXCI7XG59XG5cbmlvbi1ncmlkLm1kLmh5ZHJhdGVkIHtcbiAgdG9wOiAxMiU7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbmlvbi1ncmlkLmlvcy5oeWRyYXRlZCB7XG4gIHRvcDogMTIlO1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG5pb24tYnV0dG9uLnNraXAtYnRuLmlvcy5idXR0b24uYnV0dG9uLWZ1bGwuYnV0dG9uLXNvbGlkLmlvbi1hY3RpdmF0YWJsZS5pb24tZm9jdXNhYmxlLmh5ZHJhdGVkIHtcbiAgY29sb3I6ICMwMjY3ZmY7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtZmFtaWx5OiBcIkF2ZW5pclwiO1xufVxuXG5pb24tYnV0dG9uLnNraXAtYnRuLm1kLmJ1dHRvbi5idXR0b24tZnVsbC5idXR0b24tc29saWQuaW9uLWFjdGl2YXRhYmxlLmlvbi1mb2N1c2FibGUuaHlkcmF0ZWQge1xuICBjb2xvcjogIzAyNjdmZjtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1mYW1pbHk6IFwiQXZlbmlyXCI7XG59XG5cbmlvbi1zbGlkZS5tZC5zd2lwZXItc2xpZGUuc3dpcGVyLXpvb20tY29udGFpbmVyLmh5ZHJhdGVkLnN3aXBlci1zbGlkZS1hY3RpdmUge1xuICBoZWlnaHQ6IDg2JTtcbiAgYm9yZGVyLXJhZGl1czogMzZweDtcbiAgd2lkdGg6IDkxJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTZweDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG5pb24tc2xpZGUuaW9zLnN3aXBlci1zbGlkZS5zd2lwZXItem9vbS1jb250YWluZXIuaHlkcmF0ZWQuc3dpcGVyLXNsaWRlLWFjdGl2ZSB7XG4gIGhlaWdodDogODYlO1xuICBib3JkZXItcmFkaXVzOiAzNnB4O1xuICB3aWR0aDogOTElICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC1oZWlnaHQ6IDQyOXB4KSB7XG4gIGltZyB7XG4gICAgaGVpZ2h0OiAxNzFweCAhaW1wb3J0YW50O1xuICB9XG59XG5pb24tY29udGVudC5pb3MuaHlkcmF0ZWQge1xuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG5pb24tY29udGVudC5tZC5oeWRyYXRlZCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG4iXX0= */");

/***/ }),

/***/ "Tjpd":
/*!***************************************************!*\
  !*** ./src/app/welcome-page/welcome-page.page.ts ***!
  \***************************************************/
/*! exports provided: WelcomePagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePagePage", function() { return WelcomePagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_welcome_page_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./welcome-page.page.html */ "5XYs");
/* harmony import */ var _welcome_page_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./welcome-page.page.scss */ "G4WV");
/* harmony import */ var _common_function__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common.function */ "EU1L");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





let WelcomePagePage = class WelcomePagePage {
    constructor(config) {
        this.config = config;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
        };
        this.slideLast = false;
    }
    ngOnInit() { }
    GoNavig() {
        this.config.navigate('home');
    }
    getIndex(event) {
        this.slider.getActiveIndex().then((val) => {
            this.slideLast = val === 3;
        });
    }
};
WelcomePagePage.ctorParameters = () => [
    { type: _common_function__WEBPACK_IMPORTED_MODULE_3__["CommonService"] }
];
WelcomePagePage.propDecorators = {
    slider: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['slides',] }]
};
WelcomePagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-welcome-page',
        template: _raw_loader_welcome_page_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_welcome_page_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], WelcomePagePage);



/***/ }),

/***/ "Z6FC":
/*!*****************************************************!*\
  !*** ./src/app/welcome-page/welcome-page.module.ts ***!
  \*****************************************************/
/*! exports provided: WelcomePagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePagePageModule", function() { return WelcomePagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _welcome_page_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./welcome-page-routing.module */ "FSnL");
/* harmony import */ var _welcome_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./welcome-page.page */ "Tjpd");







let WelcomePagePageModule = class WelcomePagePageModule {
};
WelcomePagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _welcome_page_routing_module__WEBPACK_IMPORTED_MODULE_5__["WelcomePagePageRoutingModule"]
        ],
        declarations: [_welcome_page_page__WEBPACK_IMPORTED_MODULE_6__["WelcomePagePage"]]
    })
], WelcomePagePageModule);



/***/ })

}]);
//# sourceMappingURL=welcome-page-welcome-page-module.js.map