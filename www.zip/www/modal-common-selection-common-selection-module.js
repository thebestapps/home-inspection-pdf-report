(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modal-common-selection-common-selection-module"],{

/***/ "Et0V":
/*!*******************************************************************!*\
  !*** ./src/app/modal/common-selection/common-selection.module.ts ***!
  \*******************************************************************/
/*! exports provided: CommonSelectionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonSelectionPageModule", function() { return CommonSelectionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _common_selection_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./common-selection-routing.module */ "vAk8");
/* harmony import */ var _common_selection_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./common-selection.page */ "xVOy");







// import { File } from '@ionic-native/file/ngx';
// import { FileOpener } from '@ionic-native/file-opener/ngx';
let CommonSelectionPageModule = class CommonSelectionPageModule {
};
CommonSelectionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _common_selection_routing_module__WEBPACK_IMPORTED_MODULE_5__["CommonSelectionPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        ],
        providers: [],
        declarations: [_common_selection_page__WEBPACK_IMPORTED_MODULE_6__["CommonSelectionPage"]],
    })
], CommonSelectionPageModule);



/***/ }),

/***/ "vAk8":
/*!***************************************************************************!*\
  !*** ./src/app/modal/common-selection/common-selection-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: CommonSelectionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonSelectionPageRoutingModule", function() { return CommonSelectionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _common_selection_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./common-selection.page */ "xVOy");




const routes = [
    {
        path: '',
        component: _common_selection_page__WEBPACK_IMPORTED_MODULE_3__["CommonSelectionPage"]
    }
];
let CommonSelectionPageRoutingModule = class CommonSelectionPageRoutingModule {
};
CommonSelectionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CommonSelectionPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=modal-common-selection-common-selection-module.js.map