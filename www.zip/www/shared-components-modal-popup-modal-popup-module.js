(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shared-components-modal-popup-modal-popup-module"],{

/***/ "DmrL":
/*!*******************************************************************!*\
  !*** ./src/app/shared/components/modal-popup/modal-popup.page.ts ***!
  \*******************************************************************/
/*! exports provided: ModalPopupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPopupPage", function() { return ModalPopupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_popup_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-popup.page.html */ "pDF1");
/* harmony import */ var _modal_popup_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-popup.page.scss */ "Nx4o");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let ModalPopupPage = class ModalPopupPage {
    constructor(modalController) {
        this.modalController = modalController;
        this.fontColor = '#ffffff';
        this.fontValue = 18;
        this.type = 'title';
    }
    ngOnInit() {
        // console.log('Input data ', this.data);
        this.setDefaults();
    }
    setDefaults() {
        // if (this.data) {
        //   const data = {
        //     font_color: this.data.font_color,
        //     font_size: this.data.font_size,
        //     font_color_desc: this.data.font_color_desc,
        //     font_size_desc: this.data.font_size_desc,
        //   };
        //   this.outputData = data;
        // }
        if (this.data) {
            this.fontColor = this.data.font_color || '#ffffff';
            this.fontValue = this.data.font_size || '18';
        }
    }
    closeModel(data) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const value = data || false;
            yield this.modalController.dismiss(value);
        });
    }
    colorChangeEvent() {
        // console.log(this.fontColor)
    }
    getFontSize(e) {
        this.fontValue = e.detail.value;
    }
    updateData() {
        let obj = {
            font_size: this.fontValue,
            font_color: this.fontColor
        };
        this.closeModel(obj);
    }
    selectContentType(e) {
        console.log(e);
        console.log(this.type);
    }
};
ModalPopupPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalPopupPage.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
ModalPopupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-popup',
        template: _raw_loader_modal_popup_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_popup_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalPopupPage);



/***/ }),

/***/ "Nx4o":
/*!*********************************************************************!*\
  !*** ./src/app/shared/components/modal-popup/modal-popup.page.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("::ng-deep .modal-cutomise {\n  --box-shadow: 0 28px 48px rgba(0, 0, 0, 0.4);\n  --backdrop-opacity: var(--ion-backdrop-opacity, 0.32);\n}\n::ng-deep .modal-cutomise .modal-wrapper {\n  width: 80%;\n  height: 36.3%;\n}\n::ng-deep .modal-cutomise .modal-wrapper ion-content.md {\n  --background: #ffffff;\n}\n::ng-deep .modal-cutomise .modal-wrapper ion-content.md ion-item {\n  --border-color: inherit !important;\n  background: #ffffff !important;\n  border-bottom: 1px solid #dadada !important;\n}\n::ng-deep .modal-cutomise .modal-wrapper ion-content.md ion-item:last-child {\n  border-bottom: 0px solid #dadada !important;\n}\n::ng-deep .modal-cutomise .wrapper-customise {\n  background: #ffffff !important;\n}\n::ng-deep .modal-cutomise .wrapper-customise ion-item {\n  --border-color: inherit !important;\n  background: #ffffff !important;\n  border-bottom: 1px solid #dadada !important;\n}\n::ng-deep .modal-cutomise ion-text.primary {\n  background: #e2e2e2;\n  min-height: 59px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL21vZGFsLXBvcHVwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLDRDQUFBO0VBQ0EscURBQUE7QUFBSjtBQUNJO0VBQ0ksVUFBQTtFQUNBLGFBQUE7QUFDUjtBQUlRO0VBQ0kscUJBQUE7QUFGWjtBQUdZO0VBQ0ksa0NBQUE7RUFFQSw4QkFBQTtFQUNBLDJDQUFBO0FBRmhCO0FBR2dCO0VBQ0ksMkNBQUE7QUFEcEI7QUFNSTtFQUNJLDhCQUFBO0FBSlI7QUFLUTtFQUNJLGtDQUFBO0VBRUEsOEJBQUE7RUFDQSwyQ0FBQTtBQUpaO0FBUVE7RUFDSSxtQkFBQTtFQUNBLGdCQUFBO0FBTloiLCJmaWxlIjoibW9kYWwtcG9wdXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG46Om5nLWRlZXAgLm1vZGFsLWN1dG9taXNlIHtcbiAgICAtLWJveC1zaGFkb3c6IDAgMjhweCA0OHB4IHJnYmEoMCwgMCwgMCwgMC40KTtcbiAgICAtLWJhY2tkcm9wLW9wYWNpdHk6IHZhcigtLWlvbi1iYWNrZHJvcC1vcGFjaXR5LCAwLjMyKTtcbiAgICAubW9kYWwtd3JhcHBlciB7ICAgICAgICBcbiAgICAgICAgd2lkdGg6IDgwJTtcbiAgICAgICAgaGVpZ2h0OiAzNi4zJTtcbiAgICAgICAgLy8gcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAvLyB0b3A6IDUwJTtcbiAgICAgICAgLy8gbGVmdDogNTAlO1xuICAgICAgICAvLyB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgICAgICAgaW9uLWNvbnRlbnQubWQge1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmZmZmO1xuICAgICAgICAgICAgaW9uLWl0ZW17IFxuICAgICAgICAgICAgICAgIC0tYm9yZGVyLWNvbG9yOiBpbmhlcml0ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgLy8gaGVyZSBvdGhlciBjdXN0b20gQ1NTIGZyb20gZG9jdW1lbnRhdGlvblxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmZmZmYgIWltcG9ydGFudDtcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RhZGFkYSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDBweCBzb2xpZCAjZGFkYWRhICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAud3JhcHBlci1jdXN0b21pc2Uge1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG4gICAgICAgIGlvbi1pdGVteyBcbiAgICAgICAgICAgIC0tYm9yZGVyLWNvbG9yOiBpbmhlcml0ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAvLyBoZXJlIG90aGVyIGN1c3RvbSBDU1MgZnJvbSBkb2N1bWVudGF0aW9uXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmZmZmICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RhZGFkYSAhaW1wb3J0YW50O1xuICAgICAgICAgfVxuICAgIH1cbiAgICBpb24tdGV4dCB7XG4gICAgICAgICYucHJpbWFyeSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZTJlMmUyO1xuICAgICAgICAgICAgbWluLWhlaWdodDogNTlweDtcbiAgICAgICAgfVxuICAgIH1cbn0iXX0= */");

/***/ }),

/***/ "nnOa":
/*!*****************************************************************************!*\
  !*** ./src/app/shared/components/modal-popup/modal-popup-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: ModalPopupPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPopupPageRoutingModule", function() { return ModalPopupPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _modal_popup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modal-popup.page */ "DmrL");




const routes = [
    {
        path: '',
        component: _modal_popup_page__WEBPACK_IMPORTED_MODULE_3__["ModalPopupPage"]
    }
];
let ModalPopupPageRoutingModule = class ModalPopupPageRoutingModule {
};
ModalPopupPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ModalPopupPageRoutingModule);



/***/ }),

/***/ "pDF1":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/modal-popup/modal-popup.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Cutomise</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"wrapper-cutomise\">\n  <!-- <p>Choose your monster's colors:</p> -->\n\n  <ion-item>\n    <ion-text color=\"primary w-100\">\n      <p class=\"ion-text-center\" [ngStyle]=\"{'font-size': (fontValue + 'px'), 'color' : fontColor }\">\n        Sample Text</p>\n    </ion-text>\n  </ion-item>\n\n  <!-- <ion-item>\n    <ion-label>Content type</ion-label>\n    <ion-select [(ngModel)]=\"type\" okText=\"Select\" cancelText=\"Cancel\" (ionChange)=\"selectContentType($event)\">\n      <ion-select-option value=\"title\">Title</ion-select-option>\n      <ion-select-option value=\"description\">Description</ion-select-option>\n    </ion-select>\n  </ion-item> -->\n\n\n  <ion-item>\n    <ion-label slot=\"start\">Font color</ion-label>\n    <input type=\"color\" id=\"color\" name=\"color\"\n      [(ngModel)]=\"fontColor\">\n    <!-- <label for=\"color\">Font color</label> -->\n  </ion-item>\n\n<!-- <ion-button (click)=\"colorChangeEvent()\" color=\"primary\">Check</ion-button> -->\n\n<ion-item>\n  <ion-label slot=\"start\">Font size</ion-label>\n  <ion-range min=\"10\" max=\"40\" color=\"secondary\" [value]=\"fontValue\" (ionChange)=\"getFontSize($event)\">\n    <!-- <ion-label slot=\"start\">Font size</ion-label> -->\n    <ion-label slot=\"end\">{{ fontValue }} px</ion-label>\n  </ion-range>\n</ion-item>\n\n<ion-item>\n  <ion-button slot=\"start\" (click)=\"updateData()\" color=\"primary\">Save</ion-button>\n  <ion-button slot=\"end\" (click)=\"closeModel()\" color=\"primary\">Cancel</ion-button>\n</ion-item>\n</ion-content>\n");

/***/ }),

/***/ "uliD":
/*!*********************************************************************!*\
  !*** ./src/app/shared/components/modal-popup/modal-popup.module.ts ***!
  \*********************************************************************/
/*! exports provided: ModalPopupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPopupPageModule", function() { return ModalPopupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_popup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modal-popup-routing.module */ "nnOa");
/* harmony import */ var _modal_popup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modal-popup.page */ "DmrL");







let ModalPopupPageModule = class ModalPopupPageModule {
};
ModalPopupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _modal_popup_routing_module__WEBPACK_IMPORTED_MODULE_5__["ModalPopupPageRoutingModule"]
        ],
        declarations: [_modal_popup_page__WEBPACK_IMPORTED_MODULE_6__["ModalPopupPage"]]
    })
], ModalPopupPageModule);



/***/ })

}]);
//# sourceMappingURL=shared-components-modal-popup-modal-popup-module.js.map